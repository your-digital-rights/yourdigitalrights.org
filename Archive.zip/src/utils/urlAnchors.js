const searchOrganizationsUrlAnchor = "searchOrganizations";
const heroUrlAnchor = "hero";

export { searchOrganizationsUrlAnchor, heroUrlAnchor };
