# Security Policy

## Reporting a Vulnerability

Please report vulnerabilities to info@consciousdigital.org.
