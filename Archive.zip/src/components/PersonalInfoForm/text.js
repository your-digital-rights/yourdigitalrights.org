import { FormattedMessage } from "react-intl";

export const Headline = (
  <FormattedMessage
    id="personalInfoForm.headline"
    defaultMessage="Fill in the form to create a request email which you can then review and send."
    values={{
      a: txt => (<a target="_blank" href="/#faq">{txt}</a>),
    }}
  />
);

export const CompanyNameLabelText = (
  <FormattedMessage id="personalInfoForm.companyNameLabel" defaultMessage="Organization name" />
);

export const CompanyNameHelperText = (
  <FormattedMessage
    id="personalInfoForm.companyNameHelper"
    defaultMessage="Please enter the name of the organization you would like to contact."
  />
);

export const CompanyDomainLabelText = (
  <FormattedMessage id="personalInfoForm.companyDomainLabel" defaultMessage="Organization domain" />
);

export const CompanyDomainHelperText = (
  <FormattedMessage
    id="personalInfoForm.companyDomainHelper"
    defaultMessage="Please enter the domain name of the organization (example: google.co.uk or facebook.com)."
  />
);

export const CompanyEmailLabelText = (
  <FormattedMessage
    id="personalInfoForm.companyEmailLabel"
    defaultMessage="Organization email address"
  />
);

export const CompanyEmailHelperText = (
  <FormattedMessage
    id="personalInfoForm.compnayEmailHelper"
    defaultMessage="Please enter the email address of the person or department responsible for handling GDPR / CCPA / privacy / legal requests. You can usually find this information on the organization’s website under the privacy policy, terms and conditions or contact us page."
  />
);

export const NameLabelText = (
  <FormattedMessage id="personalInfoForm.nameLabel" defaultMessage="Full name" />
);

export const NameHelperText = (
  <FormattedMessage
    id="personalInfoForm.nameHelper"
    defaultMessage="This will be used by the organization to identify you."
  />
);

export const IdentifyingInfoLabelText = (
  <FormattedMessage
    id="personalInfoForm.identifyingInfoLabel"
    defaultMessage="Additional identifying information (optional)"
  />
);

export const IdentifyingInfoHelperText = (
  <FormattedMessage
    id="personalInfoForm.IdentifyingInfoHelper"
    defaultMessage="Optionally provide any additional information which will help the organization to locate your data in their information systems such as Username, Customer ID or Account Number. <strong>Please do not provide your password or any personal information which the organization does not already have.</strong>"
    values = {{
      strong: txt => (<strong>{txt}</strong>),
    }}
  />
);

export const FollowUpLabelText = (
  <FormattedMessage
    id="personalInfoForm.FollowUpLabel"
    defaultMessage="Turn on Smart Follow-up Assistance"
  />
);

export const YesFollowUpLabelText = (
  <FormattedMessage
    id="personalInfoForm.YesFollowUpLabel"
    defaultMessage="Yes, email me follow-up instructions"
  />
);

export const NoFollowUpLabelText = (
  <FormattedMessage
    id="personalInfoForm.NoFollowUpLabel"
    defaultMessage="No, I can manage on my own"
  />
);

export const FollowUpDetailsText = (
  <FormattedMessage
    id="personalInfoForm.FollowUpDetails"
    defaultMessage="To ensure that the organization complies with your request, we will email you when it’s time to take further action. You will be given the choice to send the organization a reminder email, or to escalate to the local data protection agency."
  />
);

export const FollowUpDetailsTextWarning = (
  <FormattedMessage
    id="personalInfoForm.FollowUpDetailsWarning"
    defaultMessage="<strong>By selecting this option you are agreeing to let us process and store the following personal information: your email address, name and the text of your request emails. All personal information relating to this request will be automatically deleted from our systems within 120 days, unless you specify otherwise and you always have the choice to have this data deleted immediately. We collect this information automatically by adding a special email address to the CC field of the request email.</strong>"
    values = {{
      strong: chunks => (<strong>{chunks}</strong>),
    }}
  />
);

export const SubmitButtonText = (
  <FormattedMessage id="personalInfoForm.sendButton" defaultMessage="Review and Send" />
);

export const RegulationTypeText = (
  <FormattedMessage
    id="personalInfoForm.regulationType"
    defaultMessage="Regulation"
  />
);

export const RegulationTypeHelperText = (
  <FormattedMessage
    id="personalInfoForm.regulationTypeHelper"
    defaultMessage="Choose regulation based on your place of residence, unless you have a specific reason to choose otherwise."
  />
);

export const RequestTypeLabelText = (
  <FormattedMessage
    id="personalInfoForm.requestTypeLabelText"
    defaultMessage="Request type"
  />
);

export const DeletionRequestLabelText = (
  <FormattedMessage
    id="personalInfoForm.deletionRequestLabelText"
    defaultMessage="Delete my data"
  />
);

export const AccessRequestLabelText = (
  <FormattedMessage
    id="personalInfoForm.accessRequestLabelText"
    defaultMessage="Send me a copy of my data"
  />
);

export const supportButtonCTA = (
  <FormattedMessage
    id="personalInfoForm.supportButtonCTA"
    defaultMessage="Support"
  />
);
